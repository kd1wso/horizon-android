#include "/lib/settings.glsl"

#ifdef VSH
varying vec2 texcoord;
void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    gl_Position = ftransform();
}
#endif

#ifdef FSH
uniform sampler2D colortex0;
varying vec2 texcoord;
void main() {
    vec3 original = texture2D(colortex0, texcoord).rgb;
    float luminance = dot(original, vec3(0.2126, 0.7152, 0.0722));
    vec3 color = mix(vec3(luminance), original, LITE_SATURATION);
    color = (color - 0.5) * LITE_CONTRAST + 0.5;
    color *= LITE_BRIGHTNESS * vec3(LITE_WARMTH, 1.0, 2.0 - LITE_WARMTH);
#ifdef LITE_VIGNETTE
    vec2 offset = texcoord - vec2(0.5);
    color *= 1.0 - 0.12 * dot(offset, offset);
#endif
    gl_FragColor = vec4(clamp(mix(original, color, LITE_STRENGTH), 0.0, 1.0), 1.0);
}
#endif
