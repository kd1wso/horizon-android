// Svet Lite: one texture sample per pixel; all controls are optional color adjustments.
#define LITE_BRIGHTNESS 1.00 // [0.80 0.90 1.00 1.10 1.20]
#define LITE_CONTRAST 1.05 // [0.90 0.95 1.00 1.05 1.10 1.15]
#define LITE_SATURATION 1.12 // [0.80 0.90 1.00 1.06 1.12 1.20 1.30]
#define LITE_WARMTH 1.02 // [0.90 0.95 1.00 1.02 1.05 1.10]
#define LITE_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00]
#define LITE_VIGNETTE
